package com.aman.natural.utils;

public class Constants {
    public static String PREF_NAME = "user_pref";

}
