package com.aman.natural.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.aman.natural.R;
import com.aman.natural.api.Api;
import com.aman.natural.api.UserApi;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class RegisterActivity extends AppCompatActivity {

    private EditText nameET;
    private EditText mobileET;
    private EditText emailET;
    private EditText ageET;
    private EditText genderET;
    private EditText addressET;
    private EditText emergencyPhoneET;
    private EditText bloodGroupET;
    private EditText passwordET;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");

        nameET = findViewById(R.id.nameET);
        mobileET = findViewById(R.id.mobileET);
        emailET = findViewById(R.id.emailET);
        ageET = findViewById(R.id.ageET);
        genderET = findViewById(R.id.genderET);
        addressET = findViewById(R.id.addressET);
        emergencyPhoneET = findViewById(R.id.emergencyPhoneET);
        bloodGroupET = findViewById(R.id.bloodGroupET);
        passwordET = findViewById(R.id.passwordET);

    }

    public void viewLoginClicked(View view) {
        finish();
    }

    public void onRegisterClicked(View view) {
        progressDialog.show();
        UserApi userApi = Api.getInstance().getUserApi();

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("name", nameET.getText().toString())
                .addFormDataPart("address", addressET.getText().toString())
                .addFormDataPart("email", emailET.getText().toString())
                .addFormDataPart("age", ageET.getText().toString())
                .addFormDataPart("gender", genderET.getText().toString())
                .addFormDataPart("blood_group", bloodGroupET.getText().toString())
                .addFormDataPart("phone", mobileET.getText().toString())
                .addFormDataPart("emergency_phone", emergencyPhoneET.getText().toString())
                .addFormDataPart("password", passwordET.getText().toString())
                .build();

        userApi.register(requestBody).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                try {
                    JSONObject resObject = new JSONObject(response.body().string());

                    if (resObject.getBoolean("success")) {
                        //setDefault();
                        Toast.makeText(RegisterActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(RegisterActivity.this, resObject.getString("message"), Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(RegisterActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void setDefault() {
        nameET.setText("");
        mobileET.setText("");
        emailET.setText("");
        ageET.setText("");
        genderET.setText("");
        addressET.setText("");
        emergencyPhoneET.setText("");
        bloodGroupET.setText("");
        passwordET.setText("");
    }
}