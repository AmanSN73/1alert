package com.aman.natural.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import com.aman.natural.R;
import com.aman.natural.api.Api;
import com.aman.natural.api.AssistanceApi;
import com.aman.natural.utils.Constants;

import org.json.JSONObject;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddAssistActivity extends AppCompatActivity {

    private LinearLayout mySelfLL;
    private ImageView radioBtn1;
    private EditText numberET;
    private LinearLayout otherLL;
    private ImageView radioBtn2;
    private EditText commentET;
    private Button submitButton;


    String submitType;

    ProgressDialog progressDialog;
    private String situationId;
    private LocationListener locationListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_assist);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");

        mySelfLL = findViewById(R.id.mySelfLL);
        radioBtn1 = findViewById(R.id.radioBtn1);
        numberET = findViewById(R.id.numberET);
        otherLL = findViewById(R.id.otherLL);
        radioBtn2 = findViewById(R.id.radioBtn2);
        commentET = findViewById(R.id.commentET);
        submitButton = findViewById(R.id.submitButton);

        situationId = getIntent().getExtras().getString("situation_id");

        submitButton.setOnClickListener(view -> {
            submitForm();
        });

        mySelfLL.setOnClickListener(this::selectType);

        otherLL.setOnClickListener(this::selectType);
    }

    private void selectType(View view) {
        if (view.getId() == R.id.mySelfLL) {
            submitType = "myself";
            radioBtn1.setImageResource(R.drawable.ic_baseline_radio_button_checked_24);
            radioBtn2.setImageResource(R.drawable.ic_baseline_radio_button_unchecked_24);
        } else if (view.getId() == R.id.otherLL) {
            submitType = "others";
            radioBtn2.setImageResource(R.drawable.ic_baseline_radio_button_checked_24);
            radioBtn1.setImageResource(R.drawable.ic_baseline_radio_button_unchecked_24);
        }
    }

    private void submitForm() {
        if (submitType != null && !submitType.isEmpty()) {
            if (submitType.equals("myself") && numberET.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "Please enter no. of dependents", Toast.LENGTH_SHORT).show();
                return;
            }
            getLocation();
        } else {
            Toast.makeText(this, "Please select an option", Toast.LENGTH_SHORT).show();
        }
    }

    private void submitAssistance() {

        AssistanceApi assistanceApi = Api.getInstance().getAssistanceApi();

        SharedPreferences sharedPreferences = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("situation_id", situationId)
                .addFormDataPart("type", submitType)
                .addFormDataPart("number_of_dependents", numberET.getText().toString())
                .addFormDataPart("comment", commentET.getText().toString())
                .addFormDataPart("user_id", sharedPreferences.getString("user_id", ""))
                .addFormDataPart("latitude", "" + latitude)
                .addFormDataPart("longitude", "" + longitude)
                .build();

        assistanceApi.submitAssistance(requestBody).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                try {
                    if (response.isSuccessful()) {
                        JSONObject resObject = new JSONObject(response.body().string());

                        if (resObject.getBoolean("success")) {
                            Toast.makeText(AddAssistActivity.this, "Help is on your way.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(AddAssistActivity.this, resObject.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(AddAssistActivity.this, "Error: "+response.code(), Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AddAssistActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    String[] PERMISSIONS = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

    private LocationManager locationManager;

    private void getLocation() {
        progressDialog.show();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        String provider = locationManager.getBestProvider(criteria, false);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Log.i("getloc", "IN ON LOCATION CHANGE, lat=" + location.getLatitude() + ", lon=" + location.getLongitude());
                updateLatLng(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, 2);
        } else {
            Log.i("getloc", "before request");
            locationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, locationListener, null);

        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == 2) {
            if (grantResults.length > 0) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                    locationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, locationListener, null);
                }
            }
        }
    }

    double latitude;
    double longitude;

    private void updateLatLng(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();

        submitAssistance();


        /*String city = "";
        Geocoder geocoder;
        List<Address> addresses = new ArrayList<>();
        geocoder = new Geocoder(this, Locale.ENGLISH);

        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1);

            if (addresses != null && !addresses.isEmpty()) {
                city = addresses.get(0).getLocality();
                editor.putString("uCity", ""+city);
            }


        } catch (IOException e) {
            e.printStackTrace();
        }*/


    }

}