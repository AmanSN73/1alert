package com.aman.natural.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BulletSpan;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.aman.natural.MainActivity;
import com.aman.natural.R;
import com.aman.natural.api.Api;
import com.aman.natural.api.AssistanceApi;
import com.aman.natural.api.UserApi;
import com.aman.natural.model.Situation;
import com.aman.natural.ui.adapter.SituationAdapter;
import com.aman.natural.utils.Utility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {

    private EditText searchET;

    RecyclerView situationRV;

    ProgressDialog progressDialog;
    private SituationAdapter situationAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        searchET = findViewById(R.id.searchET);
        Button searchButton = findViewById(R.id.searchButton);
        Button nextButton = findViewById(R.id.nextButton);
        situationRV = findViewById(R.id.situationRV);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");

        searchButton.setOnClickListener(view -> {
            situationAdapter.filterList(searchET.getText().toString());
        });

        nextButton.setOnClickListener(view -> {
            checkSelection();
        });

        situationRV.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        situationAdapter = new SituationAdapter(this);
        situationRV.setAdapter(situationAdapter);

        getSituations();

    }

    private void checkSelection() {
        if (situationAdapter.selectedSituation != null && !situationAdapter.selectedSituation.isEmpty()) {
            Intent assistIntent = new Intent(HomeActivity.this, AddAssistActivity.class);
            assistIntent.putExtra("situation_id", situationAdapter.selectedSituation);
            startActivity(assistIntent);
        } else {
            Toast.makeText(HomeActivity.this, "Please select an option.", Toast.LENGTH_SHORT).show();
        }
    }

    private void getSituations() {
        progressDialog.show();
        AssistanceApi assistanceApi = Api.getInstance().getAssistanceApi();

        assistanceApi.getSituations().enqueue(new Callback<ArrayList<Situation>>() {
            @Override
            public void onResponse(Call<ArrayList<Situation>> call, Response<ArrayList<Situation>> response) {
                progressDialog.dismiss();
                try {
                    if (response.isSuccessful()) {

                        //ArrayList<JSONObject> objectArrayList = Utility.jsonArrayToArrayList(resArr);

                        situationAdapter.addDataList(response.body());
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Situation>> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(HomeActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Tap again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

}