package com.aman.natural.ui.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.aman.natural.R;
import com.aman.natural.model.Situation;
import com.aman.natural.ui.HomeActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SituationAdapter extends RecyclerView.Adapter<SituationAdapter.ViewHolder> {

    private static final String TAG = SituationAdapter.class.getSimpleName();

    private Context context;
    private ArrayList<Situation> list;
    private ArrayList<Situation> allList;
    private OnItemClickListener onItemClickListener;

    public String selectedSituation;

    public SituationAdapter(Context context, ArrayList<Situation> list,
                            OnItemClickListener onItemClickListener) {
        this.context = context;
        this.list = list;
        this.onItemClickListener = onItemClickListener;
    }

    public SituationAdapter(Context context) {
        this.context = context;
        this.list = new ArrayList<>();
        this.allList = new ArrayList<>();
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void addDataList(ArrayList<Situation> listData) {
        this.list.clear();
        this.allList.clear();
        this.list.addAll(listData);
        this.allList.addAll(listData);
        notifyDataSetChanged();
    }

    public void filterList(String input) {
        list.clear();
        if (!input.trim().isEmpty()) {
            selectedSituation = null;
            for (Situation obj : allList) {
                String name = obj.name;
                if (name.toLowerCase().contains(input.toLowerCase())) {
                    list.add(obj);
                }
            }
        } else {
            list.addAll(allList);
        }
        notifyDataSetChanged();

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView radioBtn;
        public TextView situationName;

        public ViewHolder(View itemView) {
            super(itemView);

            radioBtn = itemView.findViewById(R.id.radioBtn);
            situationName = itemView.findViewById(R.id.situationName);

        }

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.situation_item, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;

    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Situation item = list.get(position);

        final String id = item.id;
        final String name = item.name;
        if (id.equals(selectedSituation)) {
            holder.radioBtn.setImageResource(R.drawable.ic_baseline_radio_button_checked_24);
        } else {
            holder.radioBtn.setImageResource(R.drawable.ic_baseline_radio_button_unchecked_24);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedSituation = id;
                notifyDataSetChanged();
            }
        });

        holder.situationName.setText(name);

    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

}