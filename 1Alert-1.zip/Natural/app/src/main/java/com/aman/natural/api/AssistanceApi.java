package com.aman.natural.api;

import com.aman.natural.model.Situation;

import java.util.ArrayList;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface AssistanceApi {

    @GET("get_situations")
    Call<ArrayList<Situation>> getSituations();

    @POST("submit_assistance")
    Call<ResponseBody> submitAssistance(@Body RequestBody body);

}