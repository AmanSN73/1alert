package com.aman.natural.utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Utility {

    public static ArrayList<JSONObject> jsonArrayToArrayList(JSONArray inputArray) {

        ArrayList<JSONObject> cList = new ArrayList<>();

        try {
            for (int i = 0; i < inputArray.length(); i++) {
                JSONObject jsonObject = inputArray.getJSONObject(i);
                cList.add(jsonObject);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return cList;
    }

}
