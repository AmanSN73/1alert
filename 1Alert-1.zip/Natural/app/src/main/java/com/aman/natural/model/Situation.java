package com.aman.natural.model;

public class Situation{
    public String id;
    public String name;
    public String created_at;
    public String updated_at;
    public String status;
}
