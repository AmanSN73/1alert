package com.aman.natural;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.aman.natural.api.Api;
import com.aman.natural.api.UserApi;
import com.aman.natural.ui.AddAssistActivity;
import com.aman.natural.ui.HomeActivity;
import com.aman.natural.ui.RegisterActivity;
import com.aman.natural.utils.Constants;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button cirLoginButton;

    ProgressDialog progressDialog;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");

        sharedPreferences = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        cirLoginButton = findViewById(R.id.cirLoginButton);

        checkPref();

        cirLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });

    }

    private void checkPref() {
        String userId = sharedPreferences.getString("user_id", "");
        String password = sharedPreferences.getString("password", "");

        if (!userId.isEmpty() && !password.isEmpty()) {
            editTextEmail.setText(userId);
            editTextPassword.setText(password);
        }
    }

    private void login() {
        progressDialog.show();
        UserApi userApi = Api.getInstance().getUserApi();

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("email", editTextEmail.getText().toString())
                .addFormDataPart("password", editTextPassword.getText().toString())
                .build();

        userApi.login(requestBody).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                try {
                    if (response.isSuccessful()) {
                        JSONObject resObject = new JSONObject(response.body().string());

                        if (resObject.getBoolean("success")) {

                            SharedPreferences.Editor editor = sharedPreferences.edit();

                            editor.putString("user_id", editTextEmail.getText().toString());
                            editor.putString("password", editTextPassword.getText().toString());
                            editor.apply();

                            Intent homeIntent = new Intent(MainActivity.this, HomeActivity.class);
                            homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(homeIntent);
                            MainActivity.this.finish();
                        } else {
                            Toast.makeText(MainActivity.this, resObject.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Error: "+response.code(), Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(MainActivity.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void viewRegisterClicked(View view) {
        Intent registerIntent = new Intent(this, RegisterActivity.class);
        startActivity(registerIntent);
    }




}